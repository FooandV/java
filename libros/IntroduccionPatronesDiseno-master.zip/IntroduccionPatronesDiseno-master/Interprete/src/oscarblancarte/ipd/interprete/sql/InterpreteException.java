package oscarblancarte.ipd.interprete.sql;

/**
 * @author Oscar Javier Blancarte Iturralde
 * @see http://www.oscarblancarteblog.com
 */
public class InterpreteException extends Exception{

    public InterpreteException(String message) {
        super(message);
    }   
}