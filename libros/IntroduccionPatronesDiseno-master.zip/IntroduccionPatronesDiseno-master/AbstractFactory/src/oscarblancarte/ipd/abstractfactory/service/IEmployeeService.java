package oscarblancarte.ipd.abstractfactory.service;

/**
 * @author Oscar Javier Blancarte Iturralde
 * @see http://www.oscarblancarteblog.com
 */
public interface IEmployeeService {
    public String[] getEmployee();
}
