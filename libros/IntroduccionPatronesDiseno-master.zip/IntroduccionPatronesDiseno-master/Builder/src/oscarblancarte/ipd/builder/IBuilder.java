package oscarblancarte.ipd.builder;

/**
 * @author oblancarte
 */
public interface IBuilder<T> {
    public T build();
}