package oscarblancarte.ipd.factorymethod;

public enum DBType {
    MySQL, Oracle,
}
