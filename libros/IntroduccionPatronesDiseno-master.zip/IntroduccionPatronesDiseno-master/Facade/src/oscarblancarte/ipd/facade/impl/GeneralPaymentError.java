package oscarblancarte.ipd.facade.impl;

/**
 * @author Oscar Javier Blancarte Iturralde.
 * @see http://oscarblancarteblog.com
 */
public class GeneralPaymentError extends Exception {

    public GeneralPaymentError(String message) {
        super(message);
    }

}