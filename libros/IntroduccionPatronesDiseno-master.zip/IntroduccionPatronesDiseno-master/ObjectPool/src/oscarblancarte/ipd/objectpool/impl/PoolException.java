package oscarblancarte.ipd.objectpool.impl;

/**
 * @author Oscar Javier Blancarte Iturralde
 * @see http://www.oscarblancarteblog.com
 */
public class PoolException extends Exception {

    public PoolException(String message) {
        super(message);
    }
}