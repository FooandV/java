# Introduction to dessing patters book - English

This repository contains the Java code, to see C# code go to next URL

[C# code](https://github.com/oscarjb1/design-patterns-cs)




# Introducción a los patrones de diseño - Español

Este repositorio contiene el código Java, para ver el código C # vaya a la siguiente URL

[C# code](https://github.com/oscarjb1/design-patterns-cs)
